package com.example.tesnsored;// LandingActivity.java

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
// Use your actual package name here


public class LandingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the new landing page layout
        setContentView(R.layout.activity_landing);

        Button startButton = findViewById(R.id.button_start);

        startButton.setOnClickListener(v -> {
            // Intent to navigate from LandingActivity to your main classification activity
            Intent intent = new Intent(LandingActivity.this, MainActivity.class);
            startActivity(intent);
            // Optional: Finish the landing activity so the user can't go back with the back button
            finish();
        });
    }
}